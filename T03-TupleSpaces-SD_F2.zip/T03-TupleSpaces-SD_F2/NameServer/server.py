import sys
sys.path.insert(1, '../Contract/target/generated-sources/protobuf/python')

import grpc
import NameServer_pb2 as pb2
import NameServer_pb2_grpc as pb2_grpc
from NamingServerServiceImpl import NamingServerServiceImpl
from concurrent import futures

# define the port
PORT = 5001
DEBUG_FLAG = True if 'Ddebug' in sys.argv else False

def debug(debug_message):
    if DEBUG_FLAG:
        print(debug_message, file=sys.stderr)

if __name__ == '__main__':
    try:
        # print received arguments
        debug("Received arguments:")
        for i in range(1, len(sys.argv)):
            debug("  " + sys.argv[i])

            # Create server
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=1))

        # add service
        pb2_grpc.add_NamingServerServiceServicer_to_server(NamingServerServiceImpl(), server)

        # listen on port
        server.add_insecure_port('[::]:'+str(PORT))

        server.start()

        print("Server listening on port " + str(PORT))
        print("Press CTRL+C to terminate")
        server.wait_for_termination()

    except KeyboardInterrupt:
        print("NameServer stopped")
        exit(0)
