import grpc
import sys
sys.path.insert(1, '../contract/target/generated-sources/protobuf/python')  # Adiciona o caminho para os ficheiros gerados pelo protobuf

import NameServer_pb2 as pb2  # Importa as definições de mensagem do protobuf
import NameServer_pb2_grpc as pb2_grpc  # Importa os serviços gRPC gerados
from NamingServer import NamingServer, ServerEntry  # Importa a classe NamingServer e a classe ServerEntry

class NamingServerServiceImpl(pb2_grpc.NamingServerService):
    
    def __init__(self, *args, **kwargs):
        self.naming_server = NamingServer()  # Inicializa uma instância de NamingServer
    
    def register(self, request, context):
        """
        Regista um servidor para um serviço.

        Args:
            request: O objeto de pedido contendo o nome do serviço, o qualificador e o endereço do servidor.
            context: O contexto da chamada RPC.

        Returns:
            Um objeto RegisterResponse em caso de sucesso.

        Raises:
            RpcError: Se não for possível registar o servidor, retorna um erro de gRPC.
        """
        nome_servico = request.service_name
        qualificador = request.qualifier
        endereco_servidor = request.server_address
        entrada_servidor = ServerEntry(endereco_servidor, qualificador)  # Cria uma instância de ServerEntry
        
        if self.naming_server.register(nome_servico, entrada_servidor) == -1:
            # Se não for possível registar o servidor, define o código de erro e detalhes
            context.set_details("Não foi possível registar o servidor")
            context.set_code(grpc.StatusCode.ALREADY_EXISTS)
            raise grpc.RpcError(grpc.StatusCode.ALREADY_EXISTS, "Não foi possível registar o servidor")
        else:
            return pb2.RegisterResponse()  # Retorna uma resposta de registo vazia em caso de sucesso
        
    def lookup(self, request, context):
        """
        Realiza uma busca por servidores para um serviço.

        Args:
            request: O objeto de pedido contendo o nome do serviço e o qualificador.
            context: O contexto da chamada RPC.

        Returns:
            Um objeto LookupResponse contendo os servidores encontrados.

        """
        return pb2.LookupResponse(servers=self.naming_server.lookup(request.service_name, request.qualifier))
    
    def delete(self, request, context):
        """
        Remove um servidor de um serviço.

        Args:
            request: O objeto de pedido contendo o nome do serviço e o endereço do servidor.
            context: O contexto da chamada RPC.

        Returns:
            Um objeto DeleteResponse em caso de sucesso.

        Raises:
            RpcError: Se não for possível remover o servidor, retorna um erro de gRPC.
        """
        if self.naming_server.delete(request.service_name, request.server_address) == -1:
            # Se não for possível remover o servidor, define o código de erro e detalhes
            context.set_details("Não foi possível remover o servidor")
            context.set_code(grpc.StatusCode.NOT_FOUND)
            raise grpc.RpcError(grpc.StatusCode.NOT_FOUND, "Não foi possível remover o servidor")
        else:
            return pb2.DeleteResponse()  # Retorna uma resposta de remoção vazia em caso de sucesso
