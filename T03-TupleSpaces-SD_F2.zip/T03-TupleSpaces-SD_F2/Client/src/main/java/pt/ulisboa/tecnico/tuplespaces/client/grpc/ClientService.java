package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.*;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesGrpc;
import pt.ulisboa.tecnico.tuplespaces.client.util.OrderedDelayer;

public class ClientService {

    /** Set flag to true to print debug messages.
     * The flag can be set using the -Ddebug command line option. */
    private static final boolean DEBUG_FLAG = (System.getProperty("debug") != null);
    private List<ManagedChannel> channels = new ArrayList<>();
    private Map<String, TupleSpacesGrpc.TupleSpacesStub> qualifiers = new HashMap<>();

    /** Helper method to print debug messages. */
    private static void debug(String debugMessage) {
        if (DEBUG_FLAG)
            System.err.println(debugMessage);
    }

    OrderedDelayer delayer;

    public ClientService(List<String> responses) {

      for (String response:responses){

        ManagedChannel channel = ManagedChannelBuilder.forTarget(response.split(",")[0]).usePlaintext().build();

        TupleSpacesGrpc.TupleSpacesStub stub = TupleSpacesGrpc.newStub(channel);

        channels.add(channel);

        qualifiers.put(response.split(", ")[1], stub);

        delayer = new OrderedDelayer(channels.size()); 
      }
    }

    public void setDelay(int id, int delay) {
      delayer.setDelay(id, delay);
      
      for (Integer i : delayer) {
        System.out.println("[Debug only]: Now I can send request to stub[" + i + "]");
    }
    System.out.println("[Debug only]: Done.");
    }
    public void closeChannel(){

      for (ManagedChannel channel: channels){
        channel.shutdown();
      }
    }

    public void put (String tuplo) {
      
      PutRequest request = PutRequest.newBuilder().setNewTuple(tuplo).build();

      ResponseCollector collector = new ResponseCollector();


      for (Map.Entry<String, TupleSpacesGrpc.TupleSpacesStub> entry : qualifiers.entrySet()){

        debug("PUT request sent: " + tuplo);

        entry.getValue().put(request, new PutObserver(collector));

      }

      collector.waitUntilAllReceived(channels.size());  

      System.out.println("OK");

      System.out.print("\n");
    }

    public void read(String pattern){

      ReadRequest request = ReadRequest.newBuilder().setSearchPattern(pattern).build();

      ResponseCollector collector = new ResponseCollector();

      for (Map.Entry<String, TupleSpacesGrpc.TupleSpacesStub> entry : qualifiers.entrySet()){

        debug("READ request sent with pattern: " + pattern);

        entry.getValue().read(request, new ReadObserver(collector));
      }

      collector.waitUntilAllReceived(1);

      System.out.println("OK");

      System.out.println(collector.getColResp().get(0));

      System.out.print("\n");
    }

    public void take(String pattern){

      TakeRequest request = TakeRequest.newBuilder().setSearchPattern(pattern).build();

      ResponseCollector collector = new ResponseCollector();

      for (Map.Entry<String, TupleSpacesGrpc.TupleSpacesStub> entry : qualifiers.entrySet()){

        debug("TAKE request sent with pattern: " + pattern);

        entry.getValue().take(request, new Observer<TakeResponse>(collector));

      }

      collector.waitUntilAllReceived(channels.size());

      System.out.println("OK");

      System.out.println(collector.getColResp());

      System.out.print("\n");
    }

    public void getTupleSpacesState(String qualifier){

      debug("GET request sent for tuple spaces state.");

      ResponseCollector collector = new ResponseCollector();

      qualifiers.get(qualifier).getTupleSpacesState(getTupleSpacesStateRequest.newBuilder().build(), new GetTupleSpacesStateObserever(collector));

      collector.waitUntilAllReceived(1);

      System.out.println("OK");

      System.out.println(collector.getColResp());

      System.out.print("\n");
    }
}