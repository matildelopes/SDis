package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.getTupleSpacesStateResponse;


public class GetTupleSpacesStateObserever implements StreamObserver<getTupleSpacesStateResponse>{
    
    ResponseCollector collector;

    public GetTupleSpacesStateObserever(ResponseCollector col) {
        collector = col;
    }

    @Override
    public void onNext(getTupleSpacesStateResponse r) {
        for (String tuple: r.getTupleList()) {
            collector.addString(tuple);
        }
        //System.out.println("Received response: " + r);
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + trowable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
}
