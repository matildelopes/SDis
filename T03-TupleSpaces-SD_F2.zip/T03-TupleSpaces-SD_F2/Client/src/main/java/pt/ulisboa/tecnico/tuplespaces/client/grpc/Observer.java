package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

public class Observer<R> implements StreamObserver<R> {

    ResponseCollector collector;

    public Observer(ResponseCollector col) {
        collector = col;
    }

    @Override
    public void onNext(R r) {
        //System.out.println("Received response: " + r);
        collector.addString(r.toString());
    }

    @Override
    public void onError(Throwable throwable) {

        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
}

