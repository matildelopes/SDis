package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.PutResponse;

public class PutObserver implements StreamObserver<PutResponse>{

    ResponseCollector collector;

    public PutObserver(ResponseCollector col) {
        collector = col;
    }

    @Override
    public void onNext(PutResponse r) {
        collector.addString("");
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
}
