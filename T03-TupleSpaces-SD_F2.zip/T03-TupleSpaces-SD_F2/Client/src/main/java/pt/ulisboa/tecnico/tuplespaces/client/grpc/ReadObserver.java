package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.ReadResponse;

public class ReadObserver implements StreamObserver<ReadResponse> {

    ResponseCollector collector;

    public ReadObserver(ResponseCollector col) {
        collector = col;
    }

    @Override
    public void onNext(ReadResponse r) {
        collector.addString(r.getResult());
        }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
    
}

