package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import java.util.ArrayList;

public class ResponseCollector {
    ArrayList<String> collectedResponses;

    public ResponseCollector(){
        collectedResponses = new ArrayList<String>();
    }

    synchronized public void addString(String s) {
        collectedResponses.add(s);
        notifyAll();
    }

    synchronized public ArrayList<String> getColResp(){
        return collectedResponses;
    }

    synchronized public void waitUntilAllReceived(int n) {
        while (collectedResponses.size() < n) {
            try {
            wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
