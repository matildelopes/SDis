package pt.ulisboa.tecnico.tuplespaces.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.ulisboa.tecnico.tuplespaces.client.grpc.ClientService;
import pt.ulisboa.tecnico.nameserver.contract.NameServer;
import pt.ulisboa.tecnico.nameserver.contract.NamingServerServiceGrpc;

public class ClientMain {

    public static void main(String[] args) {

        // check arguments
        if (args.length != 3) {
            System.err.println("Argument(s) missing!");
            System.err.println("Usage: mvn exec:java -Dexec.args=<host> <port>");
            return;
        }

        // get the host and the port
        final String host = args[0];
        final String port = args[1];
        final String target = host + ":" + port;
        
        final ManagedChannel channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();
        
        //create stub- lookup
        NamingServerServiceGrpc.NamingServerServiceBlockingStub stub = NamingServerServiceGrpc.newBlockingStub(channel);
        NameServer.LookupRequest request = NameServer.LookupRequest.newBuilder().setServiceName("TupleSpaces").setQualifier("").build();
       
        NameServer.LookupResponse response = stub.lookup(request);

        CommandProcessor parser = new CommandProcessor(new ClientService(response.getServersList()));
        
        parser.parseInput();


    }
}
