package pt.ulisboa.tecnico.tuplespaces.server;

import java.io.IOException;
import io.grpc.BindableService;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import pt.ulisboa.tecnico.nameserver.contract.NameServer;
import pt.ulisboa.tecnico.nameserver.contract.NamingServerServiceGrpc;

public class ServerMain {

    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println(ServerMain.class.getSimpleName());

        System.out.printf("Received %d arguments%n", args.length);
        for (int i = 0; i < args.length; i++) {
            System.out.printf("arg[%d] = %s%n", i, args[i]);
        }
        // check arguments
        if (args.length < 2) {
            System.err.println("Argument(s) missing!");
            System.err.printf("Usage: java %s port%n", ServerMain.class.getName());
            return;
        }

        final int port = Integer.parseInt(args[1]);
        final String target = "localhost:5001" ;
        final BindableService serImpl = new ServerImpl();
        final String qualifier = args[2];
        final String server_address = "localhost:" + port;

        // Connect to the naming server
        ManagedChannel channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();

        NamingServerServiceGrpc.NamingServerServiceBlockingStub stub = NamingServerServiceGrpc.newBlockingStub(channel);
        
        NameServer.RegisterRequest request = NameServer.RegisterRequest.newBuilder().setServiceName("TupleSpaces").setQualifier(qualifier).setServerAddress(server_address).build();    
        NameServer.RegisterResponse response = stub.register(request);

        // Create a new server to listen on port
        Server server = ServerBuilder.forPort(port).addService(serImpl).build();

        //catch "ctrl C"
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            //stop the server
            server.shutdown();
            try {
                // Try to delete the server entry from the naming server
                NameServer.DeleteRequest deleteRequest = NameServer.DeleteRequest.newBuilder().setServiceName("TupleSpaces").setServerAddress(server_address).build();
                NameServer.DeleteResponse deleteResponse = stub.delete(deleteRequest);
                System.out.println("Server entry deleted from the naming server");
            } catch (Exception erro) {
                System.err.println("Failed to delete server entry from the naming server: " + erro.getMessage());
            }
            System.out.println("Server shut down.");
        }));

        // Start the server
        server.start();

        // Server threads are running in the background.
        System.out.println("Server started");

        // Do not exit the main thread. Wait until server is terminated.
        server.awaitTermination();

        NameServer.DeleteRequest deleteRequest = NameServer.DeleteRequest.newBuilder().setServiceName("TupleSpaces").setServerAddress(server_address).build();
        NameServer.DeleteResponse deleteResponse = stub.delete(deleteRequest);
                
        }
        
    }

