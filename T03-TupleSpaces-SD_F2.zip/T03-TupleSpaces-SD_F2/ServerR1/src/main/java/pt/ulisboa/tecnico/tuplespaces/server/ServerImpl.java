package pt.ulisboa.tecnico.tuplespaces.server;
import io.grpc.stub.StreamObserver;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.*;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesGrpc;
import pt.ulisboa.tecnico.tuplespaces.server.domain.ServerState;


public class ServerImpl extends TupleSpacesGrpc.TupleSpacesImplBase{

    private ServerState ss = new ServerState();

    @Override
    public void put(PutRequest request, StreamObserver<PutResponse> responseObserver){
        
        ss.put(request.getNewTuple());

        PutResponse response = PutResponse.newBuilder().build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void read(ReadRequest request, StreamObserver<ReadResponse> responseObserver){

        String p = request.getSearchPattern();

        ReadResponse response = ReadResponse.newBuilder().setResult(ss.read(p)).build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }
    
    @Override
    public void take(TakeRequest request, StreamObserver<TakeResponse> responseObserver){

        String p = request.getSearchPattern();

        TakeResponse response = TakeResponse.newBuilder().setResult(ss.take(p)).build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void getTupleSpacesState(getTupleSpacesStateRequest request, StreamObserver<getTupleSpacesStateResponse> responseObserver){
        
        getTupleSpacesStateResponse response = getTupleSpacesStateResponse.newBuilder().addAllTuple(ss.getTupleSpacesState()).build();
        
        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }
}