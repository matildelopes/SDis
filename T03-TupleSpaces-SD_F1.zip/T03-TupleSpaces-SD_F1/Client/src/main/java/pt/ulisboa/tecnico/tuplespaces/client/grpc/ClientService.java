package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesCentralized.*;
import pt.ulisboa.tecnico.tuplespaces.centralized.contract.TupleSpacesGrpc;


public class ClientService {

    /** Set flag to true to print debug messages.
     * The flag can be set using the -Ddebug command line option. */
    private static final boolean DEBUG_FLAG = (System.getProperty("debug") != null);

    /** Helper method to print debug messages. */
    private static void debug(String debugMessage) {
        if (DEBUG_FLAG)
            System.err.println(debugMessage);
    }

    TupleSpacesGrpc.TupleSpacesBlockingStub stub;
    private final ManagedChannel channel;

    public ClientService(String host, String port) {

      final String target = host + ":" + port;

      debug("Target : " + target);

      channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();

      stub = TupleSpacesGrpc.newBlockingStub(channel);

    }

    public void closeChannel(){

      channel.shutdownNow();

    }

    public void put (String tuplo) {

      PutRequest request = PutRequest.newBuilder().setNewTuple(tuplo).build();

      debug("PUT request sent: " + tuplo);

      stub.put(request);

      System.out.println("OK");

      System.out.print("\n");
    }

    public void read(String pattern){

      ReadRequest request = ReadRequest.newBuilder().setSearchPattern(pattern).build();

      debug("READ request sent with pattern: " + pattern);

      System.out.println("OK");

      System.out.println(stub.read(request).getResult());

      System.out.print("\n");
    }

    public void take(String pattern){

      TakeRequest request = TakeRequest.newBuilder().setSearchPattern(pattern).build();

      debug("TAKE request sent with pattern: " + pattern);

      System.out.println("OK");

      System.out.println(stub.take(request).getResult());

      System.out.print("\n");
    }

    public void getTupleSpacesState() {

        getTupleSpacesStateRequest request = getTupleSpacesStateRequest.newBuilder().build();

        debug("GET request sent for tuple spaces state.");

        System.out.println("OK");

        System.out.println(stub.getTupleSpacesState(request).getTupleList());

        System.out.print("\n");
    }
}
