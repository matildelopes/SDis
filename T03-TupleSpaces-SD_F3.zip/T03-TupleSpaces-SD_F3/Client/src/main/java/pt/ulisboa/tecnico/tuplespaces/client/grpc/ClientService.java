package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;

import io.grpc.Channel;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.ulisboa.tecnico.tuplespaces.client.util.OrderedDelayer;
import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaGrpc;
import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov;
import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.*;



public class ClientService {

    /** Set flag to true to print debug messages.
     * The flag can be set using the -Ddebug command line option. */
    private static final boolean DEBUG_FLAG = (System.getProperty("debug") != null);
    private List<ManagedChannel> channels = new ArrayList<>();
    private Map<String, TupleSpacesReplicaGrpc.TupleSpacesReplicaStub> qualifiers = new HashMap<>();
    private int clientId;

    /** Helper method to print debug messages. */
    private static void debug(String debugMessage) {
        if (DEBUG_FLAG)
            System.err.println(debugMessage);
    }

    OrderedDelayer delayer;

    public ClientService(List<String> responses, int clientId) {

      for (String response:responses){

        ManagedChannel channel = ManagedChannelBuilder.forTarget(response.split(",")[0]).usePlaintext().build();

        TupleSpacesReplicaGrpc.TupleSpacesReplicaStub stub = TupleSpacesReplicaGrpc.newStub(channel);

        channels.add(channel);

        qualifiers.put(response.split(", ")[1], stub);
      }
      
      delayer = new OrderedDelayer(channels.size()); 

      this.clientId = clientId;
    }

    public void shutdown() {
        for (ManagedChannel channel : channels) {
            channel.shutdown();
        }
    }

    public void setDelay(int id, int delay) {

      delayer.setDelay(id, delay);
    }

    public String change(Integer i){

      if (i == 0) {
        
        return "A";
      }
       else if (i == 1) {
       
        return "B";
      }
       else if (i == 2) {
      
        return "C";
      } 
      
      return null;
    }

    public void closeChannel(){

      for (ManagedChannel channel: channels){
        channel.shutdown();
      }
    }

    public void put (String tuplo) {
      
      PutRequest request = PutRequest.newBuilder().setNewTuple(tuplo).build();

      ResponseCollector<String> collector = new ResponseCollector<String>();

      for (Integer i : delayer){

        debug("PUT request sent: " + tuplo);

        String qualifier = change(i);

        qualifiers.get(qualifier).put(request, new PutObserver(collector));
      }

      collector.waitUntilAllReceived(channels.size());  

      System.out.println("OK");

      System.out.print("\n");
    }

    public void read(String pattern){

      ReadRequest request = ReadRequest.newBuilder().setSearchPattern(pattern).build();

      ResponseCollector<String> collector = new ResponseCollector<String>();


      for (Integer i : delayer){

        debug("READ request sent with pattern: " + pattern);

        String qualifier = change(i);

        qualifiers.get(qualifier).read(request, new ReadObserver(collector));
      }

      collector.waitUntilAllReceived(1);

      System.out.println("OK");

      System.out.println(collector.getColResp().get(0));

      System.out.print("\n");
    }

    public void take(String pattern){

      debug("Take called with pattern: " + pattern);
      
      ResponseCollector<List<String>> collectorPhase1 = new ResponseCollector<List<String>>();

      int empty = 0;

      collectorPhase1 = phase1(pattern);

      boolean intersection = intersection(collectorPhase1);
      
        while (intersection == false){
          
          for (List<String> collector : collectorPhase1.getColResp()){
            if (collector.isEmpty())
              empty++;
          }
          if (empty > 1){
            release();
            try{
              Thread.sleep(5000);
            } catch (InterruptedException e){
              e.printStackTrace();
            }
          }

          collectorPhase1 = phase1(pattern);

          intersection = intersection(collectorPhase1);
        }

        String tuple = phase2(collectorPhase1.getColResp().get(0).get(0));

        System.out.println("OK");

        System.out.println(tuple);

        System.out.print("\n");
    }


    public ResponseCollector<List<String>> phase1(String pattern){

      TakePhase1Request requestPhase1 = TakePhase1Request.newBuilder().setSearchPattern(pattern).setClientId(clientId).build();

      ResponseCollector<List<String>> collectorPhase1 = new ResponseCollector<List<String>>();


      for (Integer i : delayer){

        debug("TAKE_phase1 request sent with pattern: " + pattern);

        String qualifier = change(i);

        qualifiers.get(qualifier).takePhase1(requestPhase1, new TakePhase1Observer(collectorPhase1));
      }

      collectorPhase1.waitUntilAllReceived(channels.size());

      return collectorPhase1;
    }

    public boolean intersection(ResponseCollector<List<String>> collectorPhase1){

      debug("Checking intersection of tuples.");

      Set<String> intersection = new HashSet<>(collectorPhase1.collectedResponses.get(0)); 

      for (List<String> tupleList : collectorPhase1.collectedResponses) {

        Set<String> tempSet = new HashSet<>(tupleList);

          intersection.retainAll(tempSet);
      }
      return (!(intersection.isEmpty()));
    }

    public void release(){

      TakePhase1ReleaseRequest requestPhase1Release = TakePhase1ReleaseRequest.newBuilder().setClientId(clientId).build();

      ResponseCollector<String> collectorPhase1Release = new ResponseCollector<String> ();

      debug("Beginning Release");

      for (Integer i : delayer){

        String qualifier = change(i);

        qualifiers.get(qualifier).takePhase1Release(requestPhase1Release, new TakePhase1ReleaseObserver(collectorPhase1Release));
      }
      
      collectorPhase1Release.waitUntilAllReceived(channels.size());

      debug("Released");
    }


    public String phase2(String tuple){

      TakePhase2Request requestPhase2 = TakePhase2Request.newBuilder().setTuple(tuple).setClientId(clientId).build();

      ResponseCollector<String> collectorPhase2 = new ResponseCollector<String>();
      
      for (Integer i : delayer){

        debug("TAKE_phase2 request sent with tuple: " + tuple);

        String qualifier = change(i);

        qualifiers.get(qualifier).takePhase2(requestPhase2, new TakePhase2Observer(collectorPhase2));
      }

      collectorPhase2.waitUntilAllReceived(channels.size());

      return tuple;
    }


    public void getTupleSpacesState(String qualifier){

      debug("GET request sent for tuple spaces state.");

      ResponseCollector<String> collector = new ResponseCollector<String>();

      qualifiers.get(qualifier).getTupleSpacesState(getTupleSpacesStateRequest.newBuilder().build(), new GetTupleSpacesStateObserever(collector));

      collector.waitUntilAllReceived(1);

      System.out.println("OK");

      System.out.println(collector.getColResp());

      System.out.print("\n");
    }
}