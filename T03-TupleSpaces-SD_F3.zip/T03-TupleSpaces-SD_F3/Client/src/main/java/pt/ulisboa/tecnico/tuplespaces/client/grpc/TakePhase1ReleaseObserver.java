package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.TakePhase1ReleaseResponse;

public class TakePhase1ReleaseObserver implements StreamObserver<TakePhase1ReleaseResponse> {

    ResponseCollector<String> collector;

    public TakePhase1ReleaseObserver(ResponseCollector<String> col) {
        collector = col;
    }

    @Override
    public void onNext(TakePhase1ReleaseResponse r) {
        collector.addR("TakePhase1ReleaseResponse");
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
    
}
