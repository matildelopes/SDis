package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import java.util.ArrayList;

public class ResponseCollector<R> {
    ArrayList<R> collectedResponses;

    public ResponseCollector(){
        collectedResponses = new ArrayList<R>();
    }

    synchronized public void addR(R s) {
        collectedResponses.add(s);
        notifyAll();
    }

    synchronized public ArrayList<R> getColResp(){
        return collectedResponses;
    }

    synchronized public void waitUntilAllReceived(int n) {
        while (collectedResponses.size() < n) {
            try {
            wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
