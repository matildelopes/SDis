package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import java.util.List;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.TakePhase1Response;


public class TakePhase1Observer implements StreamObserver<TakePhase1Response> {

    ResponseCollector<List<String>> collector;

    public TakePhase1Observer(ResponseCollector<List<String>> col) {
        collector = col;
    }

    @Override
    public void onNext(TakePhase1Response r) {
        collector.addR(r.getReservedTuplesList());
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
    
}
