package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.getTupleSpacesStateResponse;


public class GetTupleSpacesStateObserever implements StreamObserver<getTupleSpacesStateResponse>{
    
    ResponseCollector<String> collector;

    public GetTupleSpacesStateObserever(ResponseCollector<String> col) {
        collector = col;
    }

    @Override
    public void onNext(getTupleSpacesStateResponse r) {
        for (String tuple: r.getTupleList()) {
            collector.addR(tuple);
        }
        if (r.getTupleList().size() == 0) {
            collector.addR("");
        }
        //System.out.println("Received response: " + r);
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + trowable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
}
