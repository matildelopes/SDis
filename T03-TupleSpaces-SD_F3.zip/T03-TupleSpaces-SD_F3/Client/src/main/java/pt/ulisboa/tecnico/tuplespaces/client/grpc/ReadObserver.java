package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.ReadResponse;

public class ReadObserver implements StreamObserver<ReadResponse> {

    ResponseCollector<String> collector;

    public ReadObserver(ResponseCollector<String> col) {
        collector = col;
    }

    @Override
    public void onNext(ReadResponse r) {
        collector.addR(r.getResult());
        }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
    
}

