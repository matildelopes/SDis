package pt.ulisboa.tecnico.tuplespaces.client.grpc;

import io.grpc.stub.StreamObserver;

import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.PutResponse;

public class PutObserver implements StreamObserver<PutResponse>{

    ResponseCollector<String> collector;

    public PutObserver(ResponseCollector<String> col) {
        collector = col;
    }

    @Override
    public void onNext(PutResponse r) {
        collector.addR("");
    }

    @Override
    public void onError(Throwable throwable) {
        //System.out.println("Received error: " + throwable);
    }

    @Override
    public void onCompleted() {
        //System.out.println("Request completed");
    }
}
