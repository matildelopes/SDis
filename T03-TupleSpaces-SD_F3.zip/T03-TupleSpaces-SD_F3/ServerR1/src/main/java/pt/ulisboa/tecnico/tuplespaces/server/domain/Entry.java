package pt.ulisboa.tecnico.tuplespaces.server.domain;

public class Entry {

    String tuple;
    Boolean blocked;
    int id;    

    public Entry(String tuple) {
        this.tuple = tuple;
        this.blocked = false;
        this.id = -1;
    }

    public void block(int id) {
        this.blocked = true;
        this.id = id;
    }

    public String getTuple(){
        return this.tuple;
    }

    public Boolean isBlocked(){
        return this.blocked;
    }

    public void unblock(){
        this.blocked = false;
    }

    public int getId(){
        return this.id;
    }
}