package pt.ulisboa.tecnico.tuplespaces.server;
import io.grpc.stub.StreamObserver;
import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaGrpc;
import pt.ulisboa.tecnico.tuplespaces.replicaXuLiskov.contract.TupleSpacesReplicaXuLiskov.*;
import pt.ulisboa.tecnico.tuplespaces.server.domain.ServerState;


public class ServerImpl extends TupleSpacesReplicaGrpc.TupleSpacesReplicaImplBase{

    private ServerState ss = new ServerState();

    @Override
    public void put(PutRequest request, StreamObserver<PutResponse> responseObserver){
        
        ss.put(request.getNewTuple());

        PutResponse response = PutResponse.newBuilder().build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void read(ReadRequest request, StreamObserver<ReadResponse> responseObserver){

        String p = request.getSearchPattern();

        ReadResponse response = ReadResponse.newBuilder().setResult(ss.read(p)).build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }
    
    @Override
    public void takePhase1(TakePhase1Request request, StreamObserver<TakePhase1Response> responseObserver){

        String p = request.getSearchPattern();

        int id = request.getClientId();

        TakePhase1Response response = TakePhase1Response.newBuilder().addAllReservedTuples(ss.takePhase1(p, id)).build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void takePhase1Release(TakePhase1ReleaseRequest request, StreamObserver<TakePhase1ReleaseResponse> responseObserver){
            
            int id = request.getClientId();
    
            ss.takePhase1Release(id);
    
            TakePhase1ReleaseResponse response = TakePhase1ReleaseResponse.newBuilder().build();
    
            responseObserver.onNext(response);
    
            responseObserver.onCompleted();
        }

    @Override
    public void takePhase2(TakePhase2Request request, StreamObserver<TakePhase2Response> responseObserver){
        
        ss.takePhase2(request.getTuple(), request.getClientId());

        TakePhase2Response response = TakePhase2Response.newBuilder().build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void getTupleSpacesState(getTupleSpacesStateRequest request, StreamObserver<getTupleSpacesStateResponse> responseObserver){
        
        getTupleSpacesStateResponse response = getTupleSpacesStateResponse.newBuilder().addAllTuple(ss.getTupleSpacesState()).build();
        
        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }
}