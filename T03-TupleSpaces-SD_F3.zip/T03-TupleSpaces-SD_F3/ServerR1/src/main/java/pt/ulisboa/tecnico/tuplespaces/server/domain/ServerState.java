package pt.ulisboa.tecnico.tuplespaces.server.domain;

import pt.ulisboa.tecnico.tuplespaces.server.domain.Entry;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.Iterator;

public class ServerState {

  /** Set flag to true to print debug messages.
   * The flag can be set using the -Ddebug command line option. */
  private static final boolean DEBUG_FLAG = (System.getProperty("debug") != null);
  private List<Entry> entries;
  
  private ReadWriteLock lock = new ReentrantReadWriteLock();

  /** Helper method to print debug messages. */
  private static void debug(String debugMessage) {
    if (DEBUG_FLAG)
        System.err.println(debugMessage);
  }


  public ServerState() {
  
    this.entries = new ArrayList<Entry>();
  }

  public synchronized void put(String tuple) {
  
    debug("server put(" + tuple + ")");

    entries.add(new Entry(tuple));
  
    notifyAll();
  }

  private String getMatchingTuple(String pattern) {

    debug("server getMatchingTuple(" + pattern + ")");
   
    for (Entry entry : this.entries) {
   
      if (entry.getTuple().matches(pattern)) {
   
        return entry.getTuple();
      }
    }
   
    return null;
  }

  public synchronized String read(String pattern) {

    debug("server read(" + pattern + ")");

    return getMatchingTuple(pattern);
  }

  public synchronized List<String> takePhase1 (String template, int id) {

    debug("server takePhase1(" + template + ", " + id + ")");

    lock.writeLock().lock();
    List<String> tuples_to_take = new ArrayList<String>();

    for (Entry entry : this.entries) {
    
      if (entry.getTuple().matches(template) && id == entry.getId() && entry.isBlocked()) {
    
        tuples_to_take.add(entry.getTuple());
      }
      
      else if (entry.getTuple().matches(template) && !entry.isBlocked()) {
    
        tuples_to_take.add(entry.getTuple());
    
        entry.block(id);
      }
    }

    lock.writeLock().unlock();
    return tuples_to_take;
  }

  public synchronized void takePhase1Release (int id) {

    debug("server takePhase1Release(" + id + ")");

    lock.writeLock().lock();

    for (Entry entry : this.entries) {
    
      if (entry.getId() == id && entry.isBlocked()) {

    
        entry.unblock();
      }
    }

    lock.writeLock().unlock();
  }

  public synchronized void takePhase2(String template, int id) {

    debug("server takePhase2(" + template + ", " + id + ")");

    lock.writeLock().lock();

    Iterator<Entry> iterator = this.entries.iterator();
    boolean I_removed = false;
    
    while (iterator.hasNext()) {
    
      Entry entry = iterator.next();
    
      if (entry.getId() == id ) {

        if(entry.getTuple().matches(template) && !I_removed) {
          iterator.remove(); 
          I_removed = true;
          continue;
        }
        else{
          entry.unblock();
        }
    
      }
    }
    lock.writeLock().unlock();
}


  public synchronized List<String> getTupleSpacesState() {

    debug("server getTupleSpacesState()");

    List<String> tupleList = new ArrayList<String>();
    
    for (Entry entry : this.entries) {
    
      tupleList.add(entry.getTuple());
    }
    
    return tupleList;
  }
}
