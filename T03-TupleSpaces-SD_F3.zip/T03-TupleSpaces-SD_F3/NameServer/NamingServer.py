class ServerEntry:
    def __init__(self, host_port, qualifier):
        """
        Inicializa um objeto ServerEntry com o endereço do host e o qualificador.
        
        Args:
            host_port (str): Endereço do host e porta.
            qualifier (str): Qualificador do servidor.
        """
        self.host_port = host_port
        self.qualifier = qualifier

class ServiceEntry:
    def __init__(self, service_name):
        """
        Inicializa um objeto ServiceEntry com o nome do serviço.

        Args:
            service_name (str): Nome do serviço.
        """
        self.service_name = service_name
        self.servers = []

    def add_server(self, server_entry):
        """
        Adiciona um servidor ao serviço se ele ainda não estiver presente.

        Args:
            server_entry (ServerEntry): Objeto ServerEntry a ser adicionado.

        Returns:
            int: 0 se a adição for bem-sucedida, -1 caso contrário.
        """
        if server_entry not in self.servers:
            self.servers.append(server_entry)
            return 0
        return -1

class NamingServer:
    def __init__(self):
        """
        Inicializa um objeto NamingServer com um mapa de serviços.
        """
        self.service_map = {}

    def register(self, service_name, server_entry):
        """
        Regista um servidor para um serviço específico.

        Args:
            service_name (str): Nome do serviço.
            server_entry (ServerEntry): Objeto ServerEntry a ser registado.

        Returns:
            int: 0 se o registo for bem-sucedido, -1 caso contrário.
        """
        if service_name not in self.service_map.keys():
            self.service_map[service_name] = ServiceEntry(service_name)
        return self.service_map[service_name].add_server(server_entry)

    def lookup(self, service_name, qualifier):
        """
        Procura por servidores registados para um serviço específico.

        Args:
            service_name (str): Nome do serviço.
            qualifier (str): Qualificador do servidor.

        Returns:
            list: Lista de strings que representam os servidores encontrados.
        """
        if service_name not in self.service_map.keys():
            return []
        return [f"{server_entry.host_port}, {server_entry.qualifier}" for server_entry in self.service_map[service_name].servers if(qualifier =="" or server_entry.qualifier == qualifier)]

    def delete(self, service_name, host_port):
        """
        Remove um servidor registado de um serviço.

        Args:
            service_name (str): Nome do serviço.
            host_port (str): Endereço do host e porta do servidor a ser removido.

        Returns:
            int: 0 se a remoção for bem-sucedida, -1 caso contrário.
        """
        if service_name not in self.service_map.keys():
            return -1
        for server_entry in self.service_map[service_name].servers:
            if server_entry.host_port[service_name].servers == host_port:
                self.service_map[service_name].servers.remove(server_entry)
                return 0
        return -1
